<?php

	$link=mysqli_connect("localhost","root","","dcc") or die("Error: connecting database.".mysqli_connect_error());

?>