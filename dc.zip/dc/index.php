<!DOCTYPE html>
<?php
	require_once('admin/dbconnect.php');
?>
<html>
	<head>
		<title>Resume</title>
		<link rel="stylesheet" href="css/style.css" />
	</head>
	<body>
		<div class="container">
			<div class="container-inner">
			<nav id="header">
				<?php
					$query="select * from personal where uid=1";
					$result=mysqli_query($link,$query) or die("Error fetching data.".mysqli_error($link));
					$personaldetails=mysqli_fetch_assoc($result);
					mysqli_free_result($result);
					
					$query="select * from pages where page='home'";
					$result=mysqli_query($link,$query) or die("Error fetching data.".mysqli_error($link));
					$homecontent=mysqli_fetch_assoc($result);
					mysqli_free_result($result);
					
					$query="select * from social where uid=1";
					$result=mysqli_query($link,$query) or die("Error fetching data.".mysqli_error($link));
					$socialdetails=mysqli_fetch_assoc($result);
					mysqli_free_result($result);
				?>
				<ul class="nav">
					<li class="splash">
						<a href="#information">
							<div class="profile-image">
								<img src="<?php echo $personaldetails['image']; ?>" />
							</div>
							<div class="profile-info">
								<div id="varun" class="profile-name"><?php echo strtoupper($personaldetails['fname']); ?><br/><?php echo strtoupper($personaldetails['lname']); ?></div>
								<div class="profile-designation"><?php echo strtoupper($personaldetails['designation']); ?></div>
							</div>
						</a>
					</li>
					<li class="profile"><a href="#profile"><span class="icon">a</span></a></li>
					<li class="portfolio"><a href="#portfolio"><span class="icon">b</span></a></li>
					<li class="contact"><a href="#contact"><span class="icon">c</span></a></li>
				</ul>
				<div class="clear"></div>
			</nav>
			<section id="information">
				<div class="info">
					
					<div class="phone-icon"><span class="icon2">d</span></div>
					<div class="call"><?php echo $personaldetails['phone']; ?></div>
					<div class="fname"><?php echo strtoupper($personaldetails['fname']); ?>  <?php echo strtoupper($personaldetails['lname']); ?></div>
					<div class="asd"><?php echo $personaldetails['email']; ?><br/><?php echo $personaldetails['website']; ?></div>
				</div>
				<div class="social">
					<ul class="nav">
						<li class="social-icon"><a class="social-1" href="<?php echo $socialdetails['facebook']; ?>"><span class="icon">0</span></a></li>
						<li class="social-icon"><a class="social-2" href="<?php echo $socialdetails['twitter']; ?>"><span class="icon">1</span></a></li>
						<li class="social-icon"><a class="social-3" href="<?php echo $socialdetails['googleplus']; ?>"><span class="icon">2</span></a></li>
						<li class="social-icon"><a class="social-4" href="<?php echo $socialdetails['instagram']; ?>"><span class="icon">3</span></a></li>
					</ul>
				</div>
				<div class="clear"></div>
			</section>
			<section id="profile">
				
				<article class="profile-buttons">
					<button class="download">DOWNLOAD</button>
					<button class="print">PRINT</button>
				</article>
			</section>
			<section id="portfolio">
				<div class="portfolio-header">
					<ul id="portfolio-filters">
						<li><a href="*" class="current">All</a></li>
						<li><a href=".web">Web</a></li>
						<li><a href=".graphic">Graphic</a></li>
						<li><a href=".photo">Photo</a></li>
					</ul>
				</div>
				<div class="portfolio-details">
					<?php
						$query="select * from projects";
						$result=mysqli_query($link,$query) or die("Error fetching data.".mysqli_error($link));
						
						while($projectdetails=mysqli_fetch_assoc($result))
						{
					?>
					<article class="portfolio-post <?php echo $projectdetails['filter']; ?>">
						<a href="#">
							<img class="post-image" src="<?php echo $projectdetails['photo']; ?>" />
							<span class="overlay">
								<h4><?php echo $projectdetails['title']; ?></h4>
								<h5><?php echo $projectdetails['subtitle']; ?></h5>
								<img src="images/magnify.png" />
							</span>
						</a>
					</article>					
					<?php
						}
						mysqli_free_result($result);
					?>
					<!--				
					<article class="portfolio-post graphic">
						<a href="#">
							<img class="post-image" src="images/portfolio4.jpg" />
							<span class="overlay">
								<h4>Vestibulum varius ligula</h4>
								<h5>Vivamus suscipit sem</h5>
								<img src="images/magnify.png" />
							</span>
						</a>
					</article>
					<article class="portfolio-post web">
						<a href="#">
							<img class="post-image" src="images/portfolio6.jpg" />
							<span class="overlay">
								<h4>Vestibulum varius ligula</h4>
								<h5>Vivamus suscipit sem</h5>
								<img src="images/magnify.png" />
							</span>
						</a>
					</article>
					<article class="portfolio-post photo">
						<a href="#">
							<img class="post-image" src="images/portfolio10.jpg" />
							<span class="overlay">
								<h4>Vestibulum varius ligula</h4>
								<h5>Vivamus suscipit sem</h5>
								<img src="images/magnify.png" />
							</span>
						</a>
					</article>-->
					<div class="clear"></div>
				</div>
				<div class="profile-buttons">
					<button class="print">MORE RESULTS</button>
				</div>
			</section>
			<section id="contact">
				<div class="map"></div>
				<div class="contact-wrapper">
					<?php
						$query="select * from personal where uid=1";
						$result=mysqli_query($link,$query) or die("Error fetching data.".mysqli_error($link));
						$personaldetails=mysqli_fetch_assoc($result);
						mysqli_free_result($result);					
					?>
					<aside class="left-aside">
						<div class="phone-icon"><span class="icon2">d</span></div>
						<div class="call"><?php echo $personaldetails['phone']; ?></div>
						<div class="reach-me"><?php echo $personaldetails['email']; ?><br/><?php echo $personaldetails['website']; ?><br/><br/>Vcard<br/><br/><img src="images/qr.png" /></div>
					</aside>
					<aside class="right-aside">
						<div class="contact_form">
							<h3 class="title">Let's keep in touch</h3>
							<form id="contact_form" mathod="post">
								<div class="field">
									<label class="required">Name</label>
									<input type="text" name="username"/>
								</div>
								<div class="field">
									<label class="required">Email</label>
									<input type="text" name="email"/>
								</div>
								<div class="field">
									<label class="required">Message</label>
									<textarea name="message"></textarea>
								</div>
								<div class="button">
									<input type="submit" class="submit" value="submit"/>
									<div class="req">Remember to fill out all the fields.</div>
								</div>
								<div class="result"></div>
							</form>
						</div>
					</aside>
					<div class="clear"></div>
				</div>
			</section>
			</div>
			
		</div>
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/isotope.pkgd.min.js"></script>
		<script src="js/script.js"></script>
		<!-- jsPDF library -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
		<script type="text/javascript">
			function generatePDF() {
				var doc = new jsPDF();
				doc.setFontType("bold");
				var fname = "<?php echo strtoupper($personaldetails['fname']); ?>";
				var lname = "<?php echo strtoupper($personaldetails['lname']); ?>";
				var designation = "<?php echo strtoupper($personaldetails['designation']); ?>";
				var call = "<?php echo $personaldetails['phone']; ?>";
				var email = "<?php echo $personaldetails['email']; ?>";
				var website = "<?php echo $personaldetails['website']; ?>";
				
				var img = new Image;
				img.onload = function() {
					doc.addImage(this, 20, 20);
					doc.text(20, 70, 'Name: '+fname);
					doc.text(20, 80, 'Last name: '+lname);
					doc.text(20, 90, 'Designation: '+designation);
					doc.text(20, 100, 'Call: '+call);
					doc.text(20, 110, 'Email: '+email);
					doc.text(20, 120, 'Website: '+website);
					doc.save("document.pdf");
				};
				img.crossOrigin = "";  // for demo as we are at different origin than image
				img.src = "<?php echo $personaldetails['image']; ?>";
			}
			$(".download").click(function(){
				generatePDF();
				
			});
		</script>
		<?php
			require_once('admin/dbclose.php');
		?>
	</body>
</html>